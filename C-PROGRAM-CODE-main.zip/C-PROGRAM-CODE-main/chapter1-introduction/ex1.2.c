#include<stdio.h>
int main()
{
	printf("\clinumiz\c");
}
