/* basic getchar func*/
#include<stdio.h>
int main()
{
	int c;
	printf("%d",getchar()!=EOF);
}
