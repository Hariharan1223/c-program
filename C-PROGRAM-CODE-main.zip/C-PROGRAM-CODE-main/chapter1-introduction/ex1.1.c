//#include<stdio.h>
 main()
{
	printf("hello,world");

}
//printf("linumiz");
